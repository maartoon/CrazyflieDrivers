#!/usr/bin/env python3
import rosbag
import numpy as np
import matplotlib
matplotlib.use("TkAgg") 
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D
from matplotlib.widgets import Slider

pose_topic = "/cf/pose"
setpoint_topic = "/cf/setpoint"
bag_file = "circle_1.bag"

poses = []
setpoints = []
times = []

with rosbag.Bag(bag_file, "r") as bag:
    for topic, msg, t in bag.read_messages():
        if topic == pose_topic:
            poses.append([msg.pose.position.x,
                          msg.pose.position.y,
                          msg.pose.position.z])
        elif topic == setpoint_topic:
            setpoints.append([msg.transforms[0].translation.x,
                              msg.transforms[0].translation.y,
                              msg.transforms[0].translation.z])
        times.append(t.to_sec())

poses = np.array(poses)
times = np.array(times)
setpoints = np.array(setpoints)
t0 = times[0]
times -= t0  # normalize time to start at 0

# -------------------------------
# PLOT 3D TRAJECTORY 
# -------------------------------
fig = plt.figure()
ax = fig.add_subplot(111, projection="3d")

ax.plot(poses[:,0], poses[:,1], poses[:,2],
        label="Trajectory", alpha=0.3)

current_point, = ax.plot(
    [poses[0,0]], [poses[0,1]], [poses[0,2]],
    marker='o', markersize=8, color='red',
    label="Current Pose"
)

# if len(poses) > 0:
#     ax.plot(poses[:,0], poses[:,1], poses[:,2], label="Pose", linewidth=2)

if len(setpoints) > 0:
    ax.plot(setpoints[:,0], setpoints[:,1], setpoints[:,2],
            label="Setpoint", linestyle="--", linewidth=2)

ax.set_xlabel("X")
ax.set_ylabel("Y")
ax.set_zlabel("Z")
ax.legend()
ax.set_title("Pose vs Setpoint (3D)")

# --------------------------
# Slider axis
# --------------------------
slider_ax = plt.axes([0.25, 0.02, 0.55, 0.03])
time_slider = Slider(
    ax=slider_ax,
    label='Time (s)',
    valmin=0,
    valmax=len(poses) - 1,
    valinit=0,
    valstep=1
)

# --------------------------
# Slider update function
# --------------------------
def update(val):
    idx = int(time_slider.val)
    
    current_point.set_data([poses[idx,0], poses[idx,1]])
    current_point.set_3d_properties([poses[idx,2]])

    fig.canvas.draw_idle()

time_slider.on_changed(update)

plt.show()
