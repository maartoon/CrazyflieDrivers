#!/usr/bin/env python3
import rosbag
import numpy as np
import matplotlib
matplotlib.use("TkAgg") 
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D
from matplotlib.widgets import Slider
from matplotlib.animation import FuncAnimation

pose_topic = "/cf/pose"
setpoint_topic = "/cf/setpoint"
bag_file = "uturn_3.bag"

poses = []
setpoints = []
times = []

with rosbag.Bag(bag_file, "r") as bag:
    for topic, msg, t in bag.read_messages():
        if topic == pose_topic:
            poses.append([msg.pose.position.x,
                          msg.pose.position.y,
                          msg.pose.position.z])
        elif topic == setpoint_topic:
            setpoints.append([msg.transforms[0].translation.x,
                              msg.transforms[0].translation.y,
                              msg.transforms[0].translation.z])
        times.append(t.to_sec())

poses = np.array(poses)
times = np.array(times)
setpoints = np.array(setpoints)
t0 = times[0]
times -= t0  # normalize time to start at 0

# poses = poses.tolist()
# times = times.tolist()

# N = len(times)

# # Compute dt (time difference between samples)
# # The animation will use these to control playback speed
# dt = np.diff(times, prepend=times[0])  # dt[0] = 0

# # Convert dt to milliseconds for FuncAnimation
# dt_ms = dt * 1000.0


# # -------------------------------------------------------------
# # Build figure
# fig = plt.figure(figsize=(8, 6))
# ax = fig.add_subplot(111, projection='3d')

# # Plot full trajectory faintly
# ax.plot(poses[:,0], poses[:,1], poses[:,2], alpha=0.3)

# # Moving point
# point, = ax.plot(
#     [poses[0,0]], [poses[0,1]], [poses[0,2]],
#     marker='o', markersize=8, color='red'
# )

# ax.set_xlabel("X")
# ax.set_ylabel("Y")
# ax.set_zlabel("Z")
# ax.set_title("3D Trajectory Animation (No Interpolation)")

# ax.set_xlim(min(poses[:,0]), max(poses[:,0]))
# ax.set_ylim(min(poses[:,1]), max(poses[:,1]))
# ax.set_zlim(min(poses[:,2]), max(poses[:,2]))


# # -------------------------------------------------------------
# # Animation update
# def update(i):
#     x, y, z = poses[i]
#     point.set_data([x], [y])
#     point.set_3d_properties([z])
#     return point,


# # -------------------------------------------------------------
# # Custom frame interval generator matching real dt
# def frame_interval():
#     """Generator that yields frame intervals for FuncAnimation."""
#     for i in range(N):
#         yield dt_ms[i]


# # FuncAnimation cannot take a list of intervals directly,
# # but it *can* take a generator producing them.
# anim = FuncAnimation(
#     fig,
#     update,
#     frames=N,
#     interval=0,          # overridden by event_source
#     blit=True
# )

# # Override the animation timer to use real dt intervals
# timer = anim.event_source

# def step(*args):
#     try:
#         next_interval = next(intervals)
#         timer.interval = next_interval
#     except StopIteration:
#         pass

# intervals = frame_interval()
# timer.add_callback(step)

# plt.show()

def animate_3d_trajectory(poses, times, interval=30):
    """
    poses: (N, 3) array of XYZ positions
    times: (N,) array of timestamps (unused here except for reference)
    """
    print(poses[:, 0].shape)
    xs = poses[:, 0]
    ys = poses[:, 1]
    zs = poses[:, 2]

    fig = plt.figure()
    ax = fig.add_subplot(111, projection="3d")

    ax.set_xlim(np.min(xs), np.max(xs))
    ax.set_ylim(np.min(ys), np.max(ys))
    ax.set_zlim(np.min(zs), np.max(zs))

    # Full path outline (light & thin)
    ax.plot(xs, ys, zs, alpha=0.15, linewidth=1)

    # Moving point
    point, = ax.plot([], [], [], 'o', markersize=6, color='red')

    # Scatter for visited points (starts empty)
    visited = ax.scatter([], [], [], s=6)

    def update(i):
        print(times[i])
        # Move the point
        point.set_data([xs[i],], [ys[i],])
        point.set_3d_properties(zs[i])

        # Update visited points (0…i)
        visited._offsets3d = (xs[:i+1], ys[:i+1], zs[:i+1])

        return point, visited

    ani = FuncAnimation(fig, update, frames=len(poses), interval=interval, blit=False)
    plt.show()

animate_3d_trajectory(poses, times)